<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Http; // For making API requests
use Illuminate\Http\Request;

class CatalogController extends Controller
{
    // Method for fetching Business Cards category from Sinalite API
    public function businessCards()
    {
        $response = Http::get('https://sinalite-api-url.com/business-cards'); // Update with actual Sinalite API URL

        if ($response->successful()) {
            $products = $response->json(); // Convert API response to array
            return view('catalog.business-cards', compact('products'));
        } else {
            return view('catalog.business-cards')->with('error', 'Unable to fetch products.');
        }
    }

    // Method for fetching Print Products category from Sinalite API
    public function printProducts()
    {
        $response = Http::get('https://sinalite-api-url.com/print-products'); // Update with actual Sinalite API URL

        if ($response->successful()) {
            $products = $response->json();
            return view('catalog.print-products', compact('products'));
        } else {
            return view('catalog.print-products')->with('error', 'Unable to fetch products.');
        }
    }

    // Method for fetching Large Format category from Sinalite API
    public function largeFormat()
    {
        $response = Http::get('https://sinalite-api-url.com/large-format'); // Update with actual Sinalite API URL

        if ($response->successful()) {
            $products = $response->json();
            return view('catalog.large-format', compact('products'));
        } else {
            return view('catalog.large-format')->with('error', 'Unable to fetch products.');
        }
    }

    // Generic method to show a category (e.g. Business Cards, Print Products, Large Format, etc.)
    public function showCategory($category)
    {
        $response = Http::get("https://sinalite-api-url.com/{$category}"); // Update with actual Sinalite API URL

        if ($response->successful()) {
            $products = $response->json(); // Convert API response to array
            return view('catalog.category', compact('products'));
        } else {
            return view('catalog.category')->with('error', 'Unable to fetch products.');
        }
    }

    // Generic method to show a product (specific item in a category)
    public function showProduct($product)
    {
        $response = Http::get("https://sinalite-api-url.com/products/{$product}"); // Update with actual Sinalite API URL

        if ($response->successful()) {
            $productDetails = $response->json(); // Convert API response to array
            return view('catalog.product', compact('productDetails'));
        } else {
            return view('catalog.product')->with('error', 'Unable to fetch product details.');
        }
    }

    // Index method for catalog (home page of catalog)
    public function index()
    {
        // You can fetch some categories or display a simple catalog index view
        return view('catalog.index');
    }
}

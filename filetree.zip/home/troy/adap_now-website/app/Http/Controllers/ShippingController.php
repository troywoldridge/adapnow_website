<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class ShippingController extends Controller
{
    public function getShippingEstimate()
    {
        // Replace $token with your actual token retrieval logic
        $token = 'your-access-token';  // Add logic to get token dynamically if needed

        // Send the request to the Sinalite API for shipping estimate
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $token,
        ])->post('https://liveapi.sinalite.com/order/shippingEstimate', [
            'productId' => 1,  // Example Product ID
            'options' => [
                'Stock' => '30',
                'Size' => '4',
                'Qty' => '105',
                'Coating' => '93',
                'Round Corners' => '540',
                'Turnaround' => '140',
            ],
            'shippingInfo' => [
                'ShipState' => 'ON',
                'ShipZip' => 'L3R 1G3',
                'ShipCountry' => 'CA',
            ],
        ]);

        // Check if the request failed
        if ($response->failed()) {
            dd($response->status(), $response->headers(), $response->body());
        }

        // Return the shipping estimate response
        return $response->json();
    }
}

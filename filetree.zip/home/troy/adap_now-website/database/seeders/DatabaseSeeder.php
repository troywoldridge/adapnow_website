<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call([
            SetsTableSeeder::class,
            AssignSubcatagoriesSeeder::class,
            CatagoriesTablesSeeder::class,
            CoatingsTableSeeder::class,
            ProductCompatibilityTableSeeder::class,
            CompatibilitiesTableSeeder::class,
            H_standsTableSeeder::class,  // Keep only one reference to H stands seeder
            ProductCoatingTableSeeder::class,
            ProductColorTableSeeder::class,
            ProductGrommetTableSeeder::class,
            ProductHStandTableSeeder::class,
            ProductQuantityTableSeeder::class,
            ProductSetTableSeeder::class,
            ProductSizeTableSeeder::class,
            ProductsTableSeeder::class,
            ProductStockTableSeeder::class,
            ProductTurnaroundTableSeeder::class,
            ProductVariantTableSeeder::class,
            QuantitiesTableSeeder::class,
            SizesTableSeeder::class,
            StocksTableSeeder::class,
            SubcategorySeeder::class,
            TurnaroundsTableSeeder::class,
            VariantsTableSeeder::class,
        ]);
    }
}


<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Http;
use App\Models\Set;

class SetsTableSeeder extends Seeder
{
    public function run()
    {
        // Step 1: Request access token from the new token endpoint
        $tokenResponse = Http::withHeaders([
            'Content-Type' => 'application/json',
        ])->post('https://api.sinaliteuppy.com/auth/token', [
            'client_id' => 'JarBGsyG2zC4vRFTjLEi4TDbQrXUVEzr', // Your client ID
            'client_secret' => 'L292AtithgbZWAuo4UZcQXdG0s7I-TJphyaWCJKA95YpURyZGH1Qh3Ri-YauVdkJ', // Your client secret
            'audience' => 'https://liveapi.sinalite.com',  // Correct audience
            'grant_type' => 'client_credentials',
        ]);

        // Check for failed request
        if ($tokenResponse->failed()) {
            dd('Error fetching token: ', $tokenResponse->body());
        }

        // Step 2: Extract the access token from the response
        $token = $tokenResponse->json()['access_token'];

        // Step 3: Use the access token to authenticate the API request for the sets data
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $token,
        ])->get('https://liveapi.sinalite.com/sets');

        // Check if the request was successful
        if ($response->failed()) {
            dd('Error fetching sets data: ', $response->body());
        }

        // Debug the response to see the sets data
        $sets = $response->json();

        if ($sets === null) {
            dd('No sets found in the response');
        }

        // Step 4: Insert the sets data into the database
        foreach ($sets as $set) {
            Set::create([
                'name' => $set['name'],
                'description' => $set['description'],
                // Add other relevant fields based on your table structure
            ]);
        }
    }
}

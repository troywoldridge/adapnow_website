@extends('layouts.main')

@section('content')
<div class="container">
    @if (isset($error))
        <div class="alert alert-danger">{{ $error }}</div>
    @else
        <div class="row">
            <div class="col-md-6">
                <img src="{{ $productDetails['image'] }}" class="img-fluid" alt="{{ $productDetails['name'] }}">
            </div>
            <div class="col-md-6">
                <h1>{{ $productDetails['name'] }}</h1>
                <p>{{ $productDetails['description'] }}</p>
                <h4>Price: ${{ $productDetails['price'] }}</h4>
                <a href="#" class="btn btn-primary">Add to Cart</a>
            </div>
        </div>
    @endif
</div>
@endsection

@extends('layouts.main')

@section('content')
<div class="container">
    <!-- Main Heading -->
    <div class="text-center mt-5">
        <h1 class="display-4 text-primary">Welcome to American Design and Printing!</h1>
        <p class="lead text-secondary">Your one-stop shop for all printing needs</p>
    </div>

    <!-- Catalog and Business Cards Buttons -->
    <div class="d-flex justify-content-center my-4">
        <a href="{{ route('catalog.index') }}" class="btn btn-primary btn-lg mx-3">View Catalog</a>
        <a href="{{ route('business_cards.index') }}" class="btn btn-secondary btn-lg mx-3">Business Cards</a>
    </div>

    <!-- Section for Featured Product Image -->
    <div class="row mt-5 justify-content-center">
        <div class="col-md-8">
            <img src="path_to_featured_image" class="img-fluid" alt="Featured Product">
        </div>
    </div>

    <!-- Drop-Down Menus for Categories -->
    <div class="row text-center mt-5">
        <!-- Business Cards Dropdown -->
        <div class="col-md-4">
            <div class="dropdown">
                <button class="btn btn-info dropdown-toggle btn-lg" type="button" id="businessCardsDropdown" data-toggle="dropdown">
                    Business Cards
                </button>
                <div class="dropdown-menu" aria-labelledby="businessCardsDropdown">
                    <a class="dropdown-item" href="{{ route('business_cards.index', ['type' => 'standard']) }}">Standard</a>
                    <a class="dropdown-item" href="{{ route('business_cards.index', ['type' => 'specialty']) }}">Specialty</a>
                </div>
            </div>
        </div>

        <!-- Print Products Dropdown -->
        <div class="col-md-4">
            <div class="dropdown">
                <button class="btn btn-info dropdown-toggle btn-lg" type="button" id="printProductsDropdown" data-toggle="dropdown">
                    Print Products
                </button>
                <div class="dropdown-menu" aria-labelledby="printProductsDropdown">
                    <a class="dropdown-item" href="{{ route('print_products.index', ['type' => 'postcards']) }}">Postcards</a>
                    <a class="dropdown-item" href="{{ route('print_products.index', ['type' => 'flyers']) }}">Flyers</a>
                    <a class="dropdown-item" href="{{ route('print_products.index', ['type' => 'brochures']) }}">Brochures</a>
                </div>
            </div>
        </div>

        <!-- Large Format Dropdown -->
        <div class="col-md-4">
            <div class="dropdown">
                <button class="btn btn-info dropdown-toggle btn-lg" type="button" id="largeFormatDropdown" data-toggle="dropdown">
                    Large Format
                </button>
                <div class="dropdown-menu" aria-labelledby="largeFormatDropdown">
                    <a class="dropdown-item" href="{{ route('large_format.index', ['type' => 'coroplast-signs']) }}">Coroplast Signs</a>
                    <a class="dropdown-item" href="{{ route('large_format.index', ['type' => 'banners']) }}">Banners</a>
                    <a class="dropdown-item" href="{{ route('large_format.index', ['type' => 'posters']) }}">Posters</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Product Cards Section (3 Columns of Product Cards) -->
    <div class="row mt-5">
        <!-- Product Card 1 -->
        <div class="col-md-4">
            <div class="card shadow-sm">
                <img src="path_to_product_image_1" class="card-img-top" alt="Product 1 Image">
                <div class="card-body">
                    <h5 class="card-title">Product 1</h5>
                    <p class="card-text">Brief description of the product.</p>
                    <a href="#" class="btn btn-primary">View Product</a>
                </div>
            </div>
        </div>

        <!-- Product Card 2 -->
        <div class="col-md-4">
            <div class="card shadow-sm">
                <img src="path_to_product_image_2" class="card-img-top" alt="Product 2 Image">
                <div class="card-body">
                    <h5 class="card-title">Product 2</h5>
                    <p class="card-text">Brief description of the product.</p>
                    <a href="#" class="btn btn-primary">View Product</a>
                </div>
            </div>
        </div>

        <!-- Product Card 3 -->
        <div class="col-md-4">
            <div class="card shadow-sm">
                <img src="path_to_product_image_3" class="card-img-top" alt="Product 3 Image">
                <div class="card-body">
                    <h5 class="card-title">Product 3</h5>
                    <p class="card-text">Brief description of the product.</p>
                    <a href="#" class="btn btn-primary">View Product</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Repeat similar structure for more products if needed -->
</div>
@endsection

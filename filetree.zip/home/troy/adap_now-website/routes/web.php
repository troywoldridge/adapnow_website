

<?php

use App\Http\Controllers\CatalogController;
use Illuminate\Support\Facades\Route;

// Home Page Route
Route::get('/catalog', [CatalogController::class, 'index'])->name('catalog.index');


// Dynamic Routes for Business Cards, Print Products, Large Format, Stationery, Promotional Items, etc.
Route::get('/category/{category}', [CatalogController::class, 'showCategory'])->name('category.show');
Route::get('/category/{category}/{product}', [CatalogController::class, 'showProduct'])->name('product.show');

// API-related routes (if needed)
Route::get('/api/shipping-estimate', [ShippingController::class, 'getShippingEstimate']);

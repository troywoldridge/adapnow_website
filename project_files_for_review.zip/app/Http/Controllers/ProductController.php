<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Services\SinaliteService;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Routing\Controller as BaseController;

class ProductController extends BaseController
{
    protected $sinaliteService;

    public function __construct(SinaliteService $sinaliteService)
    {
        $this->sinaliteService = $sinaliteService;
    }

    // List all products
    public function index(): View
    {
        try {
            $products = Product::all(); // Fetch products from your database
            return view('products.index', ['products' => $products]);
        } catch (\Exception $e) {
            Log::error('Failed to retrieve products: ' . $e->getMessage());
            return view('products.index', ['products' => []])
                ->with('error', 'Failed to load products.');
        }
    }

    // Show details for a specific product
    public function show($id): View
    {
        try {
            $product = Product::findOrFail($id); // Fetch specific product
            return view('products.show', ['product' => $product]);
        } catch (\Exception $e) {
            Log::error('Failed to load product details: ' . $e->getMessage());
            return view('products.show', ['product' => null])
                ->with('error', 'Failed to load product details.');
        }
    }
}

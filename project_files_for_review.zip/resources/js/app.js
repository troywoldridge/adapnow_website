import 'bootstrap'; // This will load Bootstrap's JS components
import 'bootstrap/dist/css/bootstrap.min.css'; // This will load Bootstrap's CSS
